/*******************************************************************************
 *
 *  system_task.h - header file for task scheduler declarations
 *                  used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/

#ifndef SYSTEM_TASK_H_
#define SYSTEM_TASK_H_

typedef struct sys_task{
    uint8_t      status;
    uint16_t     cycle;
    void (*taskPointer)(void);
    uint32_t    lastCounterHeld;
    uint8_t     startUpOffset;

}sys_task_t;

typedef enum task_status{
    Uninitialized = 0U,        // not ready for kick-start, default status
    Active,                    // already running
    Deactive                   // initialized but not running, task "ready"
}task_status_t;

typedef enum task_numbers{
    Task_00 = 0U,
    Task_01,
    Task_02,
    Task_03,
    Task_04,
    Task_05,
    Task_06,
    Task_07,
    Task_08,
    Task_09,
    Task_10,
    Task_11,
    Task_12,
    Task_13,
    Task_14,
    Task_15
}task_number_t;

#define TASK_STARTED            ((uint8_t)(0x00))
#define TASK_NOT_READY          ((uint8_t)(0x01))
#define TASK_ALREADY_RUNNING    ((uint8_t)(0x02))
#define TASK_ALREADY_STOPPED    ((uint8_t)(0x03))
#define TASK_INITIALIZED        ((uint8_t)(0x04))

uint8_t startTask(uint8_t, uint8_t);
uint8_t stopTask(uint8_t);
uint8_t configTask(uint8_t, void (*)(void), uint16_t);
void eliminateTask(uint8_t);
void taskHandler(void);

extern void taskA(void);
extern void taskB(void);
extern void taskC(void);


#endif /* SYSTEM_TASK_H_ */
