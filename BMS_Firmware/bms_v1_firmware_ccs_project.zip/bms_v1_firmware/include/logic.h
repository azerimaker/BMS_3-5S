/*******************************************************************************
 *
 *  logic.h - header file for logic declarations used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/

#ifndef LOGIC_H_
#define LOGIC_H_

typedef enum operationMode
{
    ManualMode = 0,
    AutoMode = 1

}enum_operationMode_t;

typedef enum batt_soc
{
    BatteryIdle = 0,
    BatteryCharging = 1,
    BatteryDischarging

}enum_batt_soc_t;

typedef enum balance_mode
{
    NoBalance,
    ChargeBalance,
    IdleBalance
}enum_balance_mode_t;

typedef struct sys_fault
{
    union _bq
    {
        uint8_t byte;
        struct{
            uint8_t OCD         :1;
            uint8_t SCD         :1;
            uint8_t OV          :1;
            uint8_t UV          :1;
            uint8_t OVRD_ALERT  :1;
            uint8_t XREADY      :1;
            uint8_t i2c         :1;
            uint8_t reserved    :1;
        }bit;
    }BQ;

    union _sys
    {
        uint8_t byte;
        struct{
            uint8_t packOV      :1;
            uint8_t packUV      :1;
            uint8_t sysOC       :1;
            uint8_t sysOT       :1;
            uint8_t com         :1;
            uint8_t reserved    :3;
        }bit;
    }SYS;

    uint16_t delayCounter_1;
    uint16_t delayCounter_2;

}fault_t;

typedef struct logic
{
    enum_logic_t            newCommand;
    enum_operationMode_t    opMode;
    enum_logic_t            regbit_adc_en;
    enum_logic_t            fault_clear_cmd;
    enum_logic_t            apply_settings;
    enum_temperature_t      regbit_temp_sel;
    uint16_t                temp_change_delay;
    regSYS_CTRL2_t          regbyte_sys_ctrl2;
    regPROTECT1_t           regbyte_protect1;
    regPROTECT2_t           regbyte_protect2;
    regPROTECT3_t           regbyte_protect3;
    uint8_t                 regbyte_ov_trip;
    uint8_t                 regbyte_uv_trip;
    uint8_t                 regbyte_cellbal1;
//    uint8_t                 regbyte_cellbal2;
    uint16_t                gaugeLedCounter;

}logic_t;

typedef struct battery_t
{
    enum_batt_soc_t         SOC;
    uint8_t                 level;  //in percentage
}battery_t;



typedef struct balance
{
    enum_balance_mode_t     mode;
    enum_logic_t            cell1_5_on;
//    enum_logic_t            cell5_10_on;
    uint16_t                timer1_5;
//    uint16_t                timer5_10;
    uint16_t                totalTimer;
    uint32_t                timer_idle;
}balance_t;

typedef enum PARAM_ID
{
    /*Voltage*/
    COV_THRESHOLD, //COV_THRESHOLD = 0,
    COV_RECOVERY_THRESHOLD,
    COV_TIME,
    CUV_THRESHOLD,
    CUV_RECOVERY_THRESHOLD,
    CUV_TIME,

    /*Temperature*/
    PACK_OVER_TEMP1,
    PACK_OT_TIME1,
    PACK_OVER_TEMP2,
    PACK_OT_TIME2,

    /*Charge and Discharge*/
    PACK_END_OF_CHARGE_VOLTAGE,
    CC_CV_QUAL_TIME,
    PACK_END_OF_DISCHARGE_VOLTAGE,
    END_OF_DISCHARGE_QUAL_TIME,
    CHARGE_CURRENT,
    CHARGE_TAPER_CURRENT,
    CHARGE_TAPER_TIME,
    MAX_CHARGE_TIME,
    FULL_DISCHARGE_CLEAR_VOLTS,
    FULL_CHARGE_CLEAR_VOLTS,
    DELTA_CHARGE_V,
    CHARGE_DISCHARGE_TIME,
    DELTA_DISCHARGE_V,

    /*Balancing*/
    CELL_IMBALANCE_FAIL_THRESHOLD,
    CELL_IMBALANCE_FAIL_TIME,
    BALANCE_TIME,
    BALANCE_VOLTS_THRESHOLD,
    MIN_BALANCE_VOLTS,
    MAX_BALANCE_TIME,

    /*State-of-charge*/
    COULOMB_COUNTING_SOC_THRESHOLD

} enum_param_id_t;

//Battery pack definition
#define CELL_BALANCING_EN              1  //set to 1 to enable cell balancing
#define ONE_SECOND                     (100)    //10ms per tick
#define ONE_MINUTE                     ((uint32_t)60*ONE_SECOND)


//Battery pack information and threshold values
#define dCOV_THRESHOLD                 4200  //COV_THRESHOLD           [mV]
#define dCOV_RECOVERY_THRESHOLD        3600  //COV_RECOVERY_THRESHOLD  [mV]
#define dCOV_TIME                      5 //20 //COV_TIME (max value 32) [100ms]
#define dCUV_THRESHOLD                 3000  //CUV_THRESHOLD           [mV]
#define dCUV_RECOVERY_THRESHOLD        3000  //CUV_RECOVERY_THRESHOLD  [mV]
#define dCUV_TIME                      5 //20 //CUV_TIME (max value 32) [100ms]

#define dPACK_OVER_TEMP1               50    //BQ thermistor PACK_OVER_TEMP1   [st C]
#define dPACK_OT_TIME1                 2000  //PACK_OT_TIME1       [ms]
#define dPACK_OVER_TEMP2               50    //MSP LMT01 PACK_OVER_TEMP2   [st C]
#define dPACK_OT_TIME2                 2000  //PACK_OT_TIME2       [ms]

//PACK_END_OF_CHARGE_VOLTAGE   [mV]
#define dPACK_END_OF_CHARGE_VOLTAGE    (uint16_t)dCOV_THRESHOLD*NUMBER_OF_CELLS
#define dCC_CV_QUAL_TIME               20    //CC_CV_QUAL_TIME              [s]
//PACK_END_OF_DISCHARGE_VOLTAGE[mV]
#define dPACK_END_OF_DISCHARGE_VOLTAGE (uint16_t)dCUV_THRESHOLD*NUMBER_OF_CELLS
#define dEND_OF_DISCHARGE_QUAL_TIME    20    //END_OF_DISCHARGE_QUAL_TIME   [s]

#define dCHARGE_CURRENT                1100  //CHARGE_CURRENT               [mA]
#define dOCD_CURRENT                   300   //OCD_CURRENT                  [mA]
#define dCHARGE_TAPER_TIME             (uint32_t)240*ONE_MINUTE//CHARGE_TAPER_TIME[s]
#define dMAX_CHARGE_TIME               (uint32_t)200*ONE_MINUTE//MAX_CHARGE_TIME  [s]

//FULL_DISCHARGE_CLEAR_VOLTS   [mV]
#define dFULL_DISCHARGE_CLEAR_VOLTS    dPACK_END_OF_DISCHARGE_VOLTAGE
//FULL_CHARGE_CLEAR_VOLTS      [mV]
#define dFULL_CHARGE_CLEAR_VOLTS       dPACK_END_OF_CHARGE_VOLTAGE
#define dDELTA_CHARGE_V                300   //DELTA_CHARGE_V               [mv]
#define dCHARGE_DISCHARGE_TIME         (uint32_t)5*ONE_MINUTE//CHARGE_DISCHARGE_TIME [s]
#define dDELTA_DISCHARGE_V             200   //DELTA_DISCHARGE_V            [mV]

#define dSOV_THRESHOLD                 4200  //SOV_THRESHOLD                [mV]
#define dSOV_RECOVERY_THRESHOLD        3800  //SOV_RECOVERY_THRESHOLD       [mV]
#define dSOV_TIME                      3000  //SOV_TIME                     [ms]

#define dCELL_IMBALANCE_FAIL_THRESHOLD 200   //CELL_IMBALANCE_FAIL_THRESHOLD[mV]
#define dCELL_IMBALANCE_FAIL_TIME      (uint32_t)120*ONE_MINUTE//CELL_IMBALANCE_FAIL_TIME[s]
#define dBALANCE_TIME                  (uint32_t)1*ONE_MINUTE    //BALANCE_TIME A.K.A CB_TIME[s]
#define dBALANCE_VOLTS_THRESHOLD       4000    //BALANCE_VOLTS_THRESHOLD      [mV]
#define dMIN_BALANCE_VOLTS             dCUV_RECOVERY_THRESHOLD //MIN_BALANCE_VOLTS[mV]
#define dMAX_BALANCE_TIME              (uint32_t)120*ONE_MINUTE//MAX_BALANCE_TIME[s]

#define dCOULOMB_COUNTING_SOC_THRESHOLD 5     //COULOMB_COUNTING_SOC_THRESHOLD  [units]

#define SIMPLE_GAUGING_THRESHOLD_1  (30000)  //mV, 1 LED on
#define SIMPLE_GAUGING_THRESHOLD_2  (34000)  //mV, 2 LED on
#define SIMPLE_GAUGING_THRESHOLD_3  (36000)  //mV, 3 LED on
#define SIMPLE_GAUGING_THRESHOLD_4  (38000)  //mV, 4 LED on

#define GAUGE_LED_SHOWING_TIME  (200)        //2s with 10ms per tick

extern logic_t logic;
extern balance_t balance;
extern battery_t battery;
extern fault_t fault;
extern float32_t sysTemperature;

extern void logic_initialization(void);
extern void logic_handler(void);

static void simple_charging_balancing(void);
static void simple_idle_balancing(void);
static void simple_gauging(void);
static void fault_handler(void);

static void fault_scd_ocd_routine(void);
static void fault_ov_routine(void);
static void fault_uv_routine(void);
static void fault_xready_routine(void);

static uint8_t findMax(uint16_t*, uint8_t);
static uint8_t findMin(uint16_t*, uint8_t);

#endif /* LOGIC_H_ */
