/*******************************************************************************
 *
 *  gui_communication.c - c file for communication between the board and
 *                        the gui used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include "drivers.h"

uint8_t gui_com_rx_index;
uint8_t gui_com_buffer[BUFFER_LENGTH];
uint8_t* gui_com_tx_buffer;
uint8_t* gui_com_rx_buffer;
enum_gui_com_status_t gui_com_mode;
enum_gui_send_status_t gui_send_mode;
enum_logic_t gui_packet_received;
uint16_t gui_com_timeout_counter;

uint8_t gui_tx_index;
uint8_t gui_tx_length;

static uint8_t tx_counter;

void gui_communication_init(void)
{
    uint16_t i;
    gui_com_rx_index = 0U;
    gui_com_mode = GUI_WAITING_FOR_HEADER;
    gui_send_mode = GUI_SEND_IDLE;
    gui_packet_received = FALSE;
    gui_com_timeout_counter = 0;

    gui_tx_index = 0;
    gui_tx_length = 0;
    tx_counter = 0;

    gui_com_tx_buffer = gui_com_buffer;
    gui_com_rx_buffer = gui_com_buffer; //TX and RX are sharing the same data buffer, make sure SCI works in half-duplex mode.

    for(i=0;i<BUFFER_LENGTH;i++)
    {
        gui_com_tx_buffer[i] = 0;
    }

    scia0Init();
}

void gui_communication_handler(void)
{
    uint8_t checksum, i;
    if(scia0IsError()||(gui_com_timeout_counter > 1000))
    {

        gui_com_error_callback();

    }

    gui_com_timeout_counter++;
//==================================================================================================

    //step 1. check whether packet is received or not
    if(gui_packet_received == TRUE)
    {
        gui_com_timeout_counter = 0;
        gui_packet_received = FALSE;
        fault.SYS.bit.com = FALSE;
        //step 2. check BCC (data validation)
        checksum = 0;
        for(i=0;i<(BUFFER_LENGTH - 1);i++)
        {
            checksum += gui_com_rx_buffer[i];
        }
        checksum &= 0x00ff;

        if(checksum == gui_com_rx_buffer[BUFFER_LENGTH - 1])
        {
            //data is valid

            gui_rx_callback();

        }
        else
        {
            //data not valid
        }


    }
    else
    {
        //packet not received, do nothing
    }


//===============================================================================
// transmission
//===============================================================================
//    if(gui_com_mode == GUI_WAITING_FOR_INTERVAL)
//    {
        tx_counter++;

        if(tx_counter>50)    //interval is 500ms, handler is called every 10ms
        {
            tx_counter = 0;
            gui_com_mode = GUI_SENDING_FRAME;

            gui_tx_callback();  //prepare send data

            gui_com_send(gui_com_tx_buffer, BUFFER_LENGTH);     //including checksum
        }
//    }


}

static enum_tx_status_t gui_com_send(uint8_t* pTxbuff, uint8_t length)
{
    uint8_t i, checksum;
    if(gui_send_mode == GUI_SEND_IDLE)
    {
        gui_send_mode = GUI_SEND_BUSY;

        if(scia0IsTxReady())
        {
            gui_tx_index = 1U;
            gui_tx_length = length;

            checksum = 0U;
            for(i=0;i<(length-1);i++)
            {
                checksum += pTxbuff[i];
            }
            checksum = ~(checksum & 0xFF);
            pTxbuff[length-1] = checksum;

            //send the first byte here
            //rest of the bytes are to be sent by ISR
            scia0EnableTxInterrupt();
            scia0Write(pTxbuff[0]);

            return Tx_Started;
        }
        else
        {
            //Sci TX is not ready.
            return Tx_Error;
        }
    }
    else
    {
        gui_com_error_callback();
        return Tx_Busy;
    }
}

