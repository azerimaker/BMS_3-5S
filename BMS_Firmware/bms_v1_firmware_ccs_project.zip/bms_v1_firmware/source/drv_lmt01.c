/*******************************************************************************
 *
 *  drv_lmt01.c - c file for temperature sensor LMT01 function
 *                definitions used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include "drivers.h"

lmt01_ctrl_t lmt01;

void lmt01_init(void)
{
    //use gpio sync mode to read lmt01 feedbacks
    P1DIR &= ~BIT5;     //input of lmt01
    P1REN &= ~BIT5;     //disable pullup
    //P1SEL |= BIT5;      //select special function of the pin

    CACTL1 = CAREF0 + CAON + CAIE;          // 0.25 Vcc = -comp, on
    CACTL2 = P2CA1+P2CA3;                   // P1.5/CA5 = +comp, P2CA3~1 = 101

    lmt01.status = Lmt01Idle;
    lmt01.counter = 0;
    lmt01.period  = 100;    //10ms cycle, 1s period
    lmt01.isrPulseCount = 0;
}

void lmt01_handler(void)
{
    if(lmt01.status == Lmt01Idle)
    {
        lmt01.counter++;
        if(lmt01.counter > lmt01.period)
        {
            lmt01.counter = 0;
            lmt01.status = Lmt01Counting;

            //entry event
            // start afresh: remove & apply power
            CLEAR_READ_PACK_TMP();
            // apply power
            SET_READ_PACK_TMP();

            // clear & enable compA+ interrupt
            CACTL1 |= CAON;
            CACTL1 |= CAIE;

            //start ADC to read pack voltage
            adcResult.index = 1U;
            ADC10CTL0 &= ~ENC;
            ADC10CTL1 = INCH_4;     // input A4 = PACK
            ADC10CTL0 |= ENC;
            ADC10CTL0 |= ADC10SC;   // trigger conversion

            // reset the pulse counter
            lmt01.isrPulseCount = 0;
        }
    }
    else //lmt01.status == Lmt01Counting
    {
        lmt01.counter++;

        if(lmt01.counter > 11)  //100ms conversion + data transfer time
        {
            //temp = (pulse*256/4096) - 50
            lmt01.result = ((float32_t)lmt01.isrPulseCount / 16) - 50;

            sysTemperature = lmt01.result;

            lmt01.status = Lmt01Idle;
            lmt01.counter = 0;
            // disable compA+ interrupt
            CACTL1 &= ~CAON;
            CACTL1 &= ~CAIE;
            // remove power
            CLEAR_READ_PACK_TMP();
        }
    }
}

