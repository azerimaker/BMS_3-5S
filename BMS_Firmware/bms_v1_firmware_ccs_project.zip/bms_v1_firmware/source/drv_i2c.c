/*******************************************************************************
 *
 *  drv_i2c.c - c file for low level software driver function definitions
 *              for I2C module of MSP430G2553 used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/

#include "drivers.h"

void I2CInitialise()
{
    P1SEL |= BIT6 + BIT7;                       // Assign I2C pins to USCI_B0, P1.6 for SCL and P1.7 for SDA
    P1SEL2|= BIT6 + BIT7;                       // Assign I2C pins to USCI_B0, P1.6 for SCL and P1.7 for SDA

    ADC10AE0 &= 0x3F;
    CAPD &= 0x3F;

    UCB0CTL1 |= UCSWRST;                        // Enable SW reset, hold USCI logic in reset state
    UCB0CTL0 = UCMST+UCMODE_3 + UCSYNC;         // set to I2C mode, sync=1
    UCB0CTL1 = UCSSEL_2 + UCSWRST;              // Use SMCLK, keep SW reset
    UCB0BR0 = 200;                              // 80KHz @ 16MHz MCLK, make sure SCLK does not exceed 100KHz
    UCB0BR1 = 0;

    UCB0I2CIE = 0;
    IE2 &= ~(UCB0TXIE + UCB0RXIE);              //disable interrupts

    UCB0CTL1 |= UCSSEL_2;
    UCB0CTL1 &= ~UCSWRST;

    bqI2CError = FALSE;                         //clear fault
}

#if 0   //internal API not used.
static int8_t I2CSendByte(uint8_t I2CSlaveAddress, uint8_t data)
{
    uint16_t DelayCounter = 0;

    UCB0CTL0 |= UCMST;
    UCB0I2CSA = I2CSlaveAddress;

     UCB0CTL1 |= UCTR; //data in transmit direction
     UCB0CTL1 |= UCTXSTT; //Generate Start Condition
                          //Send Start Byte

     while(!(IFG2 & UCB0TXIFG))  //if UCB0TXIFG != 0, wait here
     {
         DelayCounter ++;
         if (DelayCounter >= DELAY_LIMIT)
             break;
     }

     if (DelayCounter >= DELAY_LIMIT)
         return -1;

     UCB0TXBUF = data;              // send the data

     DelayCounter = 0;

     while(DelayCounter < DELAY_LIMIT && !(IFG2 & UCB0TXIFG))
     {
         DelayCounter++;
     }

     if (DelayCounter >= DELAY_LIMIT)
         return -1;

     UCB0CTL1 |= UCTXSTP;           //send stop bit

     DelayCounter = 0;

     while(DelayCounter < DELAY_LIMIT && (UCB0CTL1 & UCTXSTP))
     {
         DelayCounter++;
     }

     if (DelayCounter >= DELAY_LIMIT)   //check if NACK condition occurred
         return -1;
     else
         return 0;

}
#endif

static int8_t I2CSendBytes(uint8_t I2CSlaveAddress, uint8_t *DataBuffer, uint16_t ByteCount, uint16_t *SentByte)
{
    uint16_t DelayCounter = 0;
    uint16_t NumberOfBytesSent = 0;
    uint8_t *DataPointer;

    UCB0CTL0 |= UCMST;
    UCB0I2CSA = I2CSlaveAddress;

     DataPointer = DataBuffer;

     UCB0CTL1 |= UCTR; //data in transmit direction
     UCB0CTL1 |= UCTXSTT; //Generate Start Condition
                          //Send Start Byte

     while(!(IFG2 & UCB0TXIFG))  //if UCTXSTT != 0, wait here
     {
         DelayCounter ++;
         if (DelayCounter >= DELAY_LIMIT)
             break;
     }

     if (DelayCounter >= DELAY_LIMIT)   //check if NACK condition occurred
     {
         *SentByte = NumberOfBytesSent;
         UCB0CTL1 |= UCTXSTP;
         return -1;
     }

     for(NumberOfBytesSent = 0; NumberOfBytesSent < ByteCount; NumberOfBytesSent++)
     {
         UCB0TXBUF= *DataPointer;

         DelayCounter = 0;

         while(DelayCounter < DELAY_LIMIT && (!(IFG2 & UCB0TXIFG) || (UCB0CTL1 & UCTXSTT))) //check if the byte has been sent
         {
             DelayCounter++;
         }

         if (DelayCounter >= DELAY_LIMIT)   //check if NACK condition occurred
         {
             *SentByte = NumberOfBytesSent;
             UCB0CTL1 |= UCTXSTP;               //send stop condition
             return -1;
         }

         DataPointer++;
     }

     IFG2 &= ~UCB0TXIFG;
     UCB0CTL1 |= UCTXSTP;       //send stop bit

     DelayCounter = 0;

     while(DelayCounter < DELAY_LIMIT && ((UCB0CTL1 & UCTXSTP)))
     {
         DelayCounter++;
     }

     *SentByte =  NumberOfBytesSent;

     if (DelayCounter >= DELAY_LIMIT)   //check if NACK condition occurred
     {
         UCB0CTL1 |= UCSWRST;
         return -1;
     }
     else
         return 0;
}

int8_t I2CReadBytes(uint8_t I2CSlaveAddress, uint8_t *DataBuffer, uint16_t ExpectedByteNumber, uint16_t *NumberOfReceivedBytes)
{
    uint16_t DelayCounter = 0;
    uint8_t *DataPointer;
    uint16_t *NumberOfReceivedBytesPointer;

    NumberOfReceivedBytesPointer = NumberOfReceivedBytes;
    *NumberOfReceivedBytesPointer = 0;

    UCB0CTL0 |= UCMST;
    DataPointer = DataBuffer;
    UCB0I2CSA = I2CSlaveAddress;

    UCB0CTL1 &= ~(UCTR); //data in receive direction

    UCB0CTL1 |= UCTXSTT; //Generate Start Condition

     while((UCB0CTL1 & UCTXSTT)
             )  //if UCTXSTT != 0, wait here
     {
         DelayCounter ++;
         if (DelayCounter >= DELAY_LIMIT)
             break;
     }

     if (DelayCounter >= DELAY_LIMIT || UCB0STAT & UCNACKIFG)   //check if NACK condition occurred
         return -1;

     for(*NumberOfReceivedBytesPointer = 0; *NumberOfReceivedBytesPointer < ExpectedByteNumber; (*NumberOfReceivedBytesPointer)++)
     {
         if(*NumberOfReceivedBytesPointer + 1 == ExpectedByteNumber)
             UCB0CTL1 |= UCTXSTP;

         DelayCounter = 0;

         while(DelayCounter < DELAY_LIMIT && !(IFG2 & UCB0RXIFG))
         {
             DelayCounter++;
         }

         if(DelayCounter == DELAY_LIMIT)
         {
             UCB0CTL1 |= UCSWRST;   //if I2C overtime condition occurred, reset I2C engine
             return -1;
         }

         *DataPointer = UCB0RXBUF;

         DataPointer++;
     }

     DelayCounter = 0;
     while(DelayCounter < DELAY_LIMIT && (UCB0CTL1 & UCTXSTP))
     {
         DelayCounter++;
     }

     if(DelayCounter >= DELAY_LIMIT)
     {
         UCB0CTL1 |= UCSWRST;
         return -1;
     }

     return 0;

}

#ifdef BQWITHCRC
static uint8_t CRC8(uint8_t *ptr, uint8_t len,uint8_t key)
{
    uint8_t i;
    uint8_t crc=0;
    while(len--!=0)
    {
        for(i=0x80; i!=0; i/=2)
        {
            if((crc & 0x80) != 0)
            {
                crc *= 2;
                crc ^= key;
            }
            else
                crc *= 2;

            if((*ptr & i)!=0)
                crc ^= key;
        }
        ptr++;
    }
    return(crc);
}

int8_t I2CReadRegisterByteWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t *Data)
{
    uint8_t TargetRegister = Register;
    uint16_t SentByte = 0;
    uint8_t ReadData[2];
    uint16_t ReadDataCount = 0;
    uint8_t CRCInput[2];
    uint8_t CRC = 0;
    int8_t ReadStatus = 0;
    int8_t WriteStatus = 0;

    WriteStatus = I2CSendBytes(I2CSlaveAddress, &TargetRegister, 1, &SentByte);

    ReadStatus = I2CReadBytes(I2CSlaveAddress, ReadData, 2, &ReadDataCount);

    if (ReadStatus != 0 || WriteStatus != 0)
    {
        return -1;
    }

    CRCInput[0] = (I2CSlaveAddress << 1) + 1;
    CRCInput[1] = ReadData[0];

    CRC = CRC8(CRCInput, 2, CRC_KEY);

    if (CRC != ReadData[1])
        return -1;

    *Data = ReadData[0];
    return 0;
}

int8_t I2CReadRegisterWordWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint16_t *Data)
{
    uint8_t TargetRegister = Register;
    uint16_t SentByte = 0;
    uint8_t ReadData[4];
    uint16_t ReadDataCount = 0;
    uint8_t CRCInput[2];
    uint8_t CRC = 0;
    int8_t ReadStatus = 0;
    int8_t WriteStatus = 0;

    WriteStatus = I2CSendBytes(I2CSlaveAddress, &TargetRegister, 1, &SentByte);

    ReadStatus = I2CReadBytes(I2CSlaveAddress, ReadData, 4, &ReadDataCount);

    if (ReadStatus != 0 || WriteStatus != 0)
    {
        return -1;
    }

    CRCInput[0] = (I2CSlaveAddress << 1) + 1;
    CRCInput[1] = ReadData[0];

    CRC = CRC8(CRCInput, 2, CRC_KEY);

    if (CRC != ReadData[1])
        return -1;

    CRC = CRC8(ReadData + 2, 1, CRC_KEY);

    if (CRC != ReadData[3])
        return -1;

    *Data = ReadData[0];

    *Data = (*Data << 8) + ReadData[2];

    return 0;
}

int8_t I2CReadBlockWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t *Buffer, uint8_t Length)
{
    uint8_t TargetRegister = Register;
    uint16_t SentByte = 0;
    uint8_t *ReadData = NULL, *StartData = NULL;
    uint16_t ReadDataCount = 0;
    uint8_t CRCInput[2];
    uint8_t CRC = 0;
    int8_t ReadStatus = 0;
    int8_t WriteStatus = 0;
    int8_t i;

    StartData = (uint8_t *)malloc(2 * Length);

    if (NULL == StartData)
        return -1;

    ReadData = StartData;

    WriteStatus = I2CSendBytes(I2CSlaveAddress, &TargetRegister, 1, &SentByte);

    ReadStatus = I2CReadBytes(I2CSlaveAddress, ReadData, 2 * Length, &ReadDataCount);

    if (ReadStatus != 0 || WriteStatus != 0)
    {
        free(StartData);
        StartData = NULL;

        return -1;
    }

    CRCInput[0] = (I2CSlaveAddress << 1) + 1;
    CRCInput[1] = *ReadData;

    CRC = CRC8(CRCInput, 2, CRC_KEY);

    ReadData++;
    if (CRC != *ReadData)
    {
        free(StartData);
        StartData = NULL;
        return -1;
    }
    else
        *Buffer = *(ReadData - 1);

    for(i = 1; i < Length; i++)
    {
        ReadData++;
        CRC = CRC8(ReadData, 1, CRC_KEY);
        ReadData++;
        Buffer++;

        if (CRC != *ReadData)
        {
            free(StartData);
            StartData = NULL;

            return -1;
        }
        else
            *Buffer = *(ReadData - 1);
    }

    free(StartData);
    StartData = NULL;

    return 0;
}

int8_t I2CWriteRegisterByteWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t Data)
{
    uint8_t DataBuffer[4];
    uint16_t SentByte = 0;

    DataBuffer[0] = I2CSlaveAddress << 1;
    DataBuffer[1] = Register;
    DataBuffer[2] = Data;
    DataBuffer[3] = CRC8(DataBuffer, 3, CRC_KEY);

    return(I2CSendBytes(I2CSlaveAddress, DataBuffer + 1, 3, &SentByte));
}

int8_t I2CWriteRegisterWordWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint16_t Data)
{
    uint8_t DataBuffer[6];
    uint16_t SentByte = 0;

    DataBuffer[0] = I2CSlaveAddress << 1;
    DataBuffer[1] = Register;
    DataBuffer[2] = LOW_BYTE(Data);
    DataBuffer[3] = CRC8(DataBuffer, 3, CRC_KEY);
    DataBuffer[4] = HIGH_BYTE(Data);
    DataBuffer[5] = CRC8(DataBuffer + 4, 1, CRC_KEY);

    return(I2CSendBytes(I2CSlaveAddress, DataBuffer + 1, 5, &SentByte));
}

int8_t I2CWriteBlockWithCRC(uint8_t I2CSlaveAddress, uint8_t StartAddress, uint8_t *Buffer, uint8_t Length)
{
    uint8_t *BufferCRC, *Pointer;
    int8_t i;
    uint16_t SentByte = 0;
    int8_t result;

    BufferCRC = (uint8_t*)malloc(2*Length + 2);
    if (NULL == BufferCRC)
        return -1;

    Pointer = BufferCRC;
    *Pointer = I2CSlaveAddress << 1;
    Pointer++;
    *Pointer = StartAddress;
    Pointer++;
    *Pointer = *Buffer;
    Pointer++;
    *Pointer = CRC8(BufferCRC, 3, CRC_KEY);

    for(i = 1; i < Length; i++)
    {
        Pointer++;
        Buffer++;
        *Pointer = *Buffer;
        *(Pointer + 1) = CRC8(Pointer, 1, CRC_KEY);
        Pointer++;
    }

    result = I2CSendBytes(I2CSlaveAddress, BufferCRC + 1, 2*Length + 1, &SentByte);

    free(BufferCRC);
    BufferCRC = NULL;

    return result;
}
#else
int8_t I2CWriteBlock(uint8_t I2CSlaveAddress, uint8_t StartAddress, uint8_t *Buffer, uint8_t Length)
{
    uint8_t *BufferNonCRC, *Pointer;
    int8_t i;
    uint16_t SentByte = 0;
    int8_t result;

    BufferNonCRC = (uint8_t*)malloc(2*Length + 1);
    if (NULL == Buffer)
        return -1;

    Pointer = BufferNonCRC;
    *Pointer = I2CSlaveAddress << 1;
    Pointer++;
    *Pointer = StartAddress;
    Pointer++;
    *Pointer = *Buffer;

    for(i = 1; i < Length; i++)
    {
        Pointer++;
        Buffer++;
        *Pointer = *Buffer;
        Pointer++;
    }

    result = I2CSendBytes(I2CSlaveAddress, BufferNonCRC, 2*Length, &SentByte);

    free(BufferNonCRC);
    BufferNonCRC = NULL;

    return result;
}

int8_t I2CWriteRegisterByte(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t Data)
{
    uint8_t DataBuffer[2];
    uint16_t SentByte = 0;


    DataBuffer[0] = Register;
    DataBuffer[1] = Data;

    return(I2CSendBytes(I2CSlaveAddress, DataBuffer, 2, &SentByte));
}

int8_t I2CWriteRegisterWord(uint8_t I2CSlaveAddress, uint8_t Register, uint16_t Data)
{
    uint8_t DataBuffer[3];
    uint16_t SentByte = 0;

    DataBuffer[0] = Register;
    DataBuffer[1] = LOWBYTE(Data);
    DataBuffer[2] = HIGHBYTE(Data);

    return(I2CSendBytes(I2CSlaveAddress, DataBuffer, 3, &SentByte));
}

int8_t I2CReadRegisterByte(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t *Data)
{
    uint8_t TargetRegister = Register;
    uint16_t SentByte = 0;
    uint16_t ReadDataCount = 0;
    int8_t ReadStatus = 0;
    int8_t WriteStatus = 0;

    WriteStatus = I2CSendBytes(I2CSlaveAddress, &TargetRegister, 1, &SentByte);

    ReadStatus = I2CReadBytes(I2CSlaveAddress, Data, 1, &ReadDataCount);

    if (ReadStatus != 0 || WriteStatus != 0)
    {
        return -1;
    }

    return 0;
}

int8_t I2CReadBlock(uint8_t I2CSlaveAddress, uint8_t StartRegisterAddress, uint8_t *Buffer, uint16_t BlockSize, uint16_t *NumberOfBytes)
{
    uint8_t TargetRegister = StartRegisterAddress;
    uint16_t SentByte = 0;
    int8_t ReadStatus = 0;
    int8_t WriteStatus = 0;

    WriteStatus = I2CSendBytes(I2CSlaveAddress, &TargetRegister, 1, &SentByte);

    ReadStatus = I2CReadBytes(I2CSlaveAddress, Buffer, BlockSize, NumberOfBytes);

    if(ReadStatus != 0 || WriteStatus != 0)
    {
        return -1;
    }

    return 0;
}
#endif
